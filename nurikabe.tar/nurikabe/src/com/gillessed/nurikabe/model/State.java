package com.gillessed.nurikabe.model;

public enum State {
    EMPTY,
    ISLAND,
    POOL
}
